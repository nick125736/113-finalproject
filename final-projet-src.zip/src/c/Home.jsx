// Home.jsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const [clickCount, setClickCount] = useState(0);
  

  const handleClick = () => {
    setClickCount((prevCount) => prevCount + 1);

    if (clickCount === 1) {
      window.open("https://github.com/nick125736/113-finalproject", "_blank");
    }
  };

  const a = {
    position: "fixed",
    bottom: "20px",
    left: "20px",
    width: "100px",
    height: "100px",
    backgroundColor: "transparent",
    border: "none",
    outline: "none",
  };

  const img = {
    padding: "20px",
  }

  return (
    <div>
      <nav className="navbar">
        <Link to="/">首頁</Link>
        <Link to="/dog">狗</Link>
        <Link to="/cat">貓</Link>
      </nav>
      <h1>歡迎來到首頁</h1>
      <h1>請點擊上方的"狗"或"貓"來查看資訊</h1>
      <div style={img}>
        <img src="https://media1.tenor.com/m/JR07yhHdk2kAAAAC/patronar.gif" alt="" style={img}/>
        <img src="https://c.tenor.com/Lnp4NR-tlLAAAAAd/tenor.gif" alt="" height="331" width="498" style={img}/>
      </div>
      
      <button onClick={handleClick} style={a}>
        Bob ！
      </button>
    </div>
  );
};

export default Home;
